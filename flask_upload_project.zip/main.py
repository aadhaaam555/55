from flask import Flask, render_template, request, redirect
import os

app = Flask(__name__)
UPLOAD_FOLDER = '5'

# تأكد من وجود المجلد
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('welcome.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        video = request.files.get('video')
        if video:
            video.save(os.path.join(UPLOAD_FOLDER, video.filename))
            return f"تم رفع الملف: {video.filename}"
    return render_template('upload.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=9090)
